package ea.ciges.testCaller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCallerApplicationTests {

	@Test
	void contextLoads() {
	}

}
